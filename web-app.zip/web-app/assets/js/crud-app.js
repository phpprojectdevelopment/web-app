var base_url = $("#base_url").val();
$(document).ready(function(){
    function getAllRecords(){  
      $.ajax({
        url: base_url+"Crud_app/getRecords",
        type:"GET",
        dataType:"JSON",
        success:function(res){
          if(res.status=='failed'){
            alert(res.message);
            return false;
          }
          showAllRecords(res.data);
        }
      });
    }
    
    getAllRecords();

    function showAllRecords(records){
      data = records;
      totalRecords=records.length;
      rows = '';
      for(i=0;i<totalRecords;i++){
        rows += '<tr>';
        rows += '<td>'+data[i].id+'</td>';
        rows += '<td>'+data[i].dns_records+'</td>';
        rows += '<td>'+data[i].internet_host_name+'</td>';
        rows += '<td>'+data[i].client_ip_address+'</td>';
        rows += '<td>'+data[i].mac_address+'</td>';
        rows += '<td><span onclick="editData(\''+data[i].id+'\',\''+data[i].dns_records+'\',\''+data[i].internet_host_name+'\',\''+data[i].client_ip_address+'\',\''+data[i].mac_address+'\');" class="btn btn-success btn-sm">Edit <i class="fa fa-pencil-square-o"></i></span>';
        rows += ' <a href="javaScript:void(0);" onclick="deleteData('+data[i].id+');" class="btn btn-danger btn-sm">Delete <i class="fa fa-trash-o"></i></a></td>';
        rows += '</tr>';
      }
      $('#crudData').html(rows).show();
    }

    $("#openNewEntryForm").on('click',function(){
      $("#editId,#dns_records,#internet_host_name,#client_ip_address,#mac_address").val("");
      $("#myModal").modal('show');
    });

    $("#submitBtn").unbind('click').on('click', function(){
      saveData();
    });

    $(".close").unbind('click').on('click', function(){
      location.reload(true);
    });
    
  });
  
  function editData(id,dns_records,internet_host_name,client_ip_address,mac_address){
    $("#editId").val(id);
    $("#dns_records").val(dns_records);
    $("#internet_host_name").val(internet_host_name);
    $("#client_ip_address").val(client_ip_address);
    $("#mac_address").val(mac_address);
    $("#myModal").modal('show');
  }
  function deleteData(deleteId) {
    if(confirm("Are you sure to delete this ?")){
        $.ajax({
          url:base_url+"Crud_app/deleteDNSRecords",
          type:"POST",
          data:{id:deleteId},
          dataType:"JSON",
          success:function(res){
            if(res.status=='success'){
              location.reload(true);
            }
          }
        });
    }
  }
  function saveData(){
    foundErr = false;
    id = $("#editId").val();
    dns_records = $("#dns_records").val();
    internet_host_name = $("#internet_host_name").val();
    client_ip_address = $("#client_ip_address").val();
    mac_address = $("#mac_address").val();

    if(dns_records==null || dns_records==''){
      $("#dns_recordsErr").html("DNS records required");
      foundErr=true;
    }
    if(internet_host_name==null || internet_host_name==''){
      $("#internet_host_nameErr").html("Internet host name required");
      foundErr=true;
    }
    if(client_ip_address==null || client_ip_address==''){
      $("#client_ip_addressErr").html("Client IP address required");
      foundErr=true;
    }
    if(mac_address==null || mac_address==''){
      $("#mac_addressErr").html("MAC address required");
      foundErr=true;
    }

    if(dns_records!=''){
      $("#dns_recordsErr").html("");
    }
    if(internet_host_name!=''){
      $("#internet_host_nameErr").html("");
    }
    if(client_ip_address!=''){
      $("#client_ip_addressErr").html("");
    }
    if(mac_address!=''){
      $("#mac_addressErr").html("");
    }

    dataSend = {id:id,dns_records:dns_records,internet_host_name:internet_host_name,client_ip_address:client_ip_address,mac_address:mac_address};

    if(foundErr==false){
      $.ajax({
        url:base_url+"Crud_app/setData",
        type:"POST",
        data:dataSend,
        dataType:"JSON",
        success:function(res){
          if(res.status=='failed'){
            if (res.message=='DNS records required') {
              $("#dns_recordsErr").html(res.message);
            } else if (res.message=='Internet host required') {
              $("#internet_host_nameErr").html(res.message);
            } else if (res.message=='Client IP address required') {
              $("#client_ip_addressErr").html(res.message);
            } else if (res.message=='MAC address required') {
              $("#mac_addressErr").html(res.message);
            }
          } else if (res.status=='success') {
            $("#crudAppForm,.modal-title").hide();
            $("#showServerMsg").html(res.message).show();
          } else {
            // alert();
          }
          
        }
      });
    }

  }