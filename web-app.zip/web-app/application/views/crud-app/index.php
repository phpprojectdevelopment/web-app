<?php $this->load->view('crud-app/header'); ?>
<div class="container">
    <a href="javaScript:void(0);" id="openNewEntryForm" class="btn btn-primary pull-right bottom-gap">Add New <i class="fa fa-plus" aria-hidden="true"></i></a>
    <table class="table table-bordered">
        <thead id="thead" style="background-color:lightgray">
            <tr>
                <th>Sr.No</th>
                <th>DNS records</th>
                <th>Internet host name</th>
                <th>Client IP address</th>
                <th>MAC address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="crudData"></tbody>
    </table>
</div>

<div class="modal fade" id="myModal" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" style="min-height:150px;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">CRUD Application Form</h4>
            </div>
            <div class="modal-body">
                <form id="crudAppForm">
                   <div class="row">
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="name">DNS Records <span class="field-required">*</span></label>
                               <input type="text" name="dns_records" id="dns_records" placeholder="DNS Records" class="form-control" value="">
                               <p id="dns_recordsErr" style="color:red;font-size:12px;"></p>
                           </div>
                       </div>
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="email">Internet Host Name <span class="field-required">*</span></label>
                               <input type="text" name="internet_host_name" id="internet_host_name" placeholder="Internet Host Name" class="form-control" value="">
                               <p id="internet_host_nameErr" style="color:red;font-size:12px;"></p>
                           </div>
                       </div>
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="contact">Client IP Address <span class="field-required">*</span></label>
                               <input type="text" name="client_ip_address" id="client_ip_address" placeholder="Client IP Address" class="form-control" value="">
                               <p id="client_ip_addressErr" style="color:red;font-size:12px;"></p>
                           </div>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="contact">MAC Address <span class="field-required">*</span></label>
                               <input type="text" name="mac_address" id="mac_address" placeholder="MAC Address" class="form-control" value="">
                               <p id="mac_addressErr" style="color:red;font-size:12px;"></p>
                           </div>
                       </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <input type="hidden" name="editId" id="editId" value="" />
                            <input type="hidden" name="base_url" id="base_url" value="<?php echo base_url(); ?>" />
                            <a href="javaScript:void(0)" id="submitBtn" class="btn btn-primary">Save</a>
                        </div>
                    </div>
                </form>
            </div>
            <div id="showServerMsg" class="col-md-12" style="display:none;text-align:center;"></div>
        </div>
    </div>
</div>
<?php $this->load->view('crud-app/footer'); ?>