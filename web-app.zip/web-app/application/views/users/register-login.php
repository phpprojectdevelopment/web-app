<?php $this->load->view('users/header') ?>
<div class="top-content">
    <div class="inner-bg">
        <div class="container">
        	
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2 text">
                    <h1><strong>&nbsp;</strong> Login &amp; Register Forms</h1>
                </div>
            </div>
            
            <div class="row">
                <div class="col-sm-5">
                	
                	<div class="form-box">
                    	<div class="form-top">
                    		<div class="form-top-left">
                    			<h3>Login to our site</h3>
                        		<p>Enter username and password to log on:</p>
                    		</div>
                    		<div class="form-top-right">
                    			<i class="fa fa-lock"></i>
                    		</div>
                        </div>
                        <div class="form-bottom">
		                    	<div class="form-group">
		                    		<label class="sr-only" for="form-username">Email</label>
		                        	<input type="text" name="login_email" placeholder="Email..." class="form-username form-control" id="form-username" value="">
                                    <p id="login_emailErr" style="color:red;background:black;padding:0 10px;"></p>
                                    <p id="login_invalidEmailErr" style="color:red;background:black;padding:0 10px;"></p>
		                        </div>
		                        <div class="form-group">
		                        	<label class="sr-only" for="form-password">Password</label>
		                        	<input type="password" name="login_password" placeholder="Password..." class="form-password form-control" id="form-password" value="">
                                    <p id="login_passwordErr" style="color:red;background:black;padding:0 10px;"></p>
                                    <p id="login_passwordNotMatchingErr" style="color:red;background:black;padding:0 10px;"></p>
                                    <p id="logindetailserr" style="color:red;background:black;padding:0 10px;"></p>
		                        </div>
		                        <button type="submit" id="login" class="btn">Sign in!</button>
	                    </div>
                    </div>
                </div>
                
                <div class="col-sm-1 middle-border"></div>
                <div class="col-sm-1"></div>
                	
                <div class="col-sm-5">
                	<!-- <p id="serverRes" style="color:red;background:black;padding:0 10px;"></p> -->
                	<div class="form-box">
                		<div class="form-top">
                    		<div class="form-top-left">
                    			<h3>Sign up now</h3>
                        		<p>Fill in the form below to get instant access:</p>
                    		</div>
                    		<div class="form-top-right">
                    			<i class="fa fa-pencil"></i>
                    		</div>
                        </div>
                        <div class="form-bottom">
		                    <!-- <form role="form" action="<?php echo base_url();?>user/registerUser" method="post" class="registration-form"> -->
		                    	<div class="form-group">
		                    		<label class="sr-only" for="form-first-name">First name</label>
		                        	<input type="text" name="firstname" placeholder="First name..." class="form-first-name form-control" id="form-first-name" value="">
                                    <p id="firstnameErr" style="color:red;background:black;padding:0 10px;"></p>
		                        </div>
		                        <div class="form-group">
		                        	<label class="sr-only" for="form-last-name">Last name</label>
		                        	<input type="text" name="lastname" placeholder="Last name..." class="form-last-name form-control" id="form-last-name" value="">
                                    <p id="lastnameErr" style="color:red;background:black;padding:0 10px;"></p>
		                        </div>
		                        <div class="form-group">
		                        	<label class="sr-only" for="form-email">Email</label>
		                        	<input type="text" name="reg_email" placeholder="Email..." class="form-email form-control" id="form-email" value="">
                                    <p id="reg_emailErr" style="color:red;background:black;padding:0 10px;"></p>
                                    <p id="reg_invalidEmailErr" style="color:red;background:black;padding:0 10px;"></p>
		                        </div>
                                <div class="form-group">
                                    <label class="sr-only" for="form-email">Password</label>
                                    <input type="password" name="reg_password" placeholder="Password..." class="form-email form-control" value="">
                                    <p id="reg_passwordErr" style="color:red;background:black;padding:0 10px;"></p>
                                </div>
                                <div class="form-group">
                                    <label class="sr-only" for="form-email">Confirm Password</label>
                                    <input type="password" name="confirm_password" placeholder="Confirm Password..." class="form-email form-control" value="">
                                    <p id="confirm_passwordErr" style="color:red;background:black;padding:0 10px;"></p>
                                    <p id="passwordNotMatchingErr" style="color:red;background:black;padding:0 10px;"></p>
                                </div>
		                        <button type="submit" id="register" class="btn">Sign me up!</button>
		                    <!-- </form> -->
	                    </div>
                	</div>
                	
                </div>
            </div>
            
        </div>
    </div>
</div>

<div class="modal fade" id="myModal" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content" style="min-height:150px;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <!-- <h4 class="modal-title">CRUD Application Form</h4> -->
            </div>
            <div id="showServerMsg" class="col-md-12" style="display:none;text-align:center;"></div>
        </div>
    </div>
</div>

<script src="<?php echo base_url() ?>assets/js/jquery-1.11.1.min.js"></script>
<script>    
$("#register").on('click',function(){
    foundErr=false;
    firstname = $("input[name=firstname]").val();
    lastname = $("input[name=lastname]").val();
    email = $("input[name=reg_email]").val();
    password = $("input[name=reg_password]").val();
    confirm_password = $("input[name=confirm_password]").val();

    if(firstname==null || firstname==''){
        $("#firstnameErr").html("Firstname required");
        foundErr=true;
    }
    if(lastname==null || lastname==''){
        $("#lastnameErr").html("Lastname required");
        foundErr=true;
    }
    if(email==null || email==''){
        $("#reg_emailErr").html("Email required");
        foundErr=true;
    }
    if(password==null || password==''){
        $("#reg_passwordErr").html("Password required");
        foundErr=true;
    }
    if(confirm_password==null || confirm_password==''){
        $("#confirm_passwordErr").html("Confirm password required");
        foundErr=true;
    }
    if(password!=confirm_password){
        $("#reg_passwordErr,#confirm_passwordErr").html("");
        $("#passwordNotMatchingErr").html("Password not matching");
        foundErr=true;
    }
    if(checkValidEmail(email)==false){
        $("#reg_emailErr").html("");
        $("#reg_invalidEmailErr").html("Invalid email");
        foundErr=true;
    }

    if(firstname!=''){
        $("#firstnameErr").html("");
    }
    if(lastname!=''){
        $("#lastnameErr").html("");
    }
    if(email!=''){
        $("#reg_emailErr").html("");
    }
    if(password!=''){
        $("#reg_passwordErr").html("");
    }
    if(confirm_password!=''){
        $("#confirm_passwordErr").html("");
    }
    if(password==confirm_password){
        $("#passwordNotMatchingErr").html("");
    }

    dataSend = {firstname:firstname,lastname:lastname,email:email,password:password,confirm_password:confirm_password};

    if(foundErr==false){

        $.ajax({
        url:"<?php echo base_url(); ?>user/registerUser",
        type:"POST",
        data:dataSend,
        dataType:"JSON",
        success:function(res){
            if(res.status=='failed'){
                if (res.message=='Firstname required') {
                    $("#firstnameErr").html(res.message);
                } else if (res.message=='Lastname required') {
                    $("#lastnameErr").html(res.message);
                } else if (res.message=='Invalid email') {
                    $("#reg_emailErr").html(res.message);
                } else if (res.message=='Password not matching') {
                    $("#passwordNotMatchingErr").html(res.message);
                }
            } else if (res.status=='success') {
                $("#myModal").modal('show');
                $("#showServerMsg").html(res.message).show();
            } else {
                // alert();
            }
        }
        });
    }
})

$(".close").unbind('click').on('click', function(){
    location.reload(true);
});

$('#login').on('click',function(){
    foundErr=false;
    email = $("input[name=login_email]").val();
    password = $("input[name=login_password]").val();

    if(email==null || email==''){
        $("#login_emailErr").html("Email required");
        foundErr=true;
    }
    if(password==null || password==''){
        $("#login_passwordErr").html("Password required");
        foundErr=true;
    }
    if(checkValidEmail(email)==false){
        $("#login_emailErr").html("");
        $("#login_invalidEmailErr").html("Invalid email");
        foundErr=true;
    }

    if(email!=''){
        $("#login_emailErr").html("");
    }
    if(password!=''){
        $("#login_passwordErr").html("");
    }
    if(checkValidEmail(email)==true){
        $("#login_invalidEmailErr").html("");
    }
    dataSend = {email:email,password:password};

    if(foundErr==false){

        $.ajax({
        url:"<?php echo base_url(); ?>user/checkLogin",
        type:"POST",
        data:dataSend,
        dataType:"JSON",
        success:function(res){
            if(res.status=='failed'){
                if (res.message=='Invalid email') {
                    $("#login_invalidEmailErr").html(res.message);
                } else if (res.message=='Password not matching') {
                    $("#login_passwordNotMatchingErr").html(res.message);
                } else if (res.message=='Login credentails not matching') {
                    $("#logindetailserr").html(res.message);
                }
            } else if (res.status=='success') {
                window.location.href="<?php echo base_url() ?>Crud_app/showNetworkRouterList";
            } else {
                // alert();
            }
        }
        });
    }
});

function checkValidEmail(myEmail){
    atpos = myEmail.indexOf("@");
    dotpos = myEmail.lastIndexOf(".");
    if(atpos<1 || dotpos<atpos+2 || dotpos+2>=myEmail.length){
        return false;
    }
    return true;
}
</script>
<?php $this->load->view('users/footer') ?>