<!-- Footer -->
<footer>
    <div class="container">
    <div class="row">

    <div class="col-sm-8 col-sm-offset-2">
    <div class="footer-border"></div>
    <p>Made by People at <a href="http://mindtree.com" target="_blank"><strong>mindtree.com</strong></a>
    having a lot of fun. <i class="fa fa-smile-o"></i></p>
    </div>

    </div>
    </div>
</footer>
<!-- Javascript -->
<!-- <script src="<?php echo base_url() ?>assets/js/jquery-1.11.1.min.js"></script> -->
<script src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/jquery.backstretch.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/scripts.js"></script>
<!--[if lt IE 10]>
<script src="assets/js/placeholder.js"></script>
<![endif]-->
</body>
</html>