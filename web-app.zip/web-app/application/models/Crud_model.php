<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud_model extends CI_Model{
	public function __construct(){
		$this->load->database();
	}

	public function getNetworkRouterProperties($page_number){
		$records = ($page_number!=null)?((($page_number-1)*10). ',' . 10):10;
		return $this->db->query('SELECT `id`,`dns_records`,`internet_host_name`,`client_ip_address`,`mac_address` FROM `network_router_properties`ORDER BY `id` DESC LIMIT '.$records)->result_array();
	}
	public function newEntry($data){
		if($data!=null){
			$this->db->insert('network_router_properties',$data);
			return ($this->db->affected_rows()>=1)?true:false;
		}
	}
	public function updateData($id,$data){
		if($data!=null){
			$this->db->where(['id'=>$id])->update('network_router_properties',$data);
			return ($this->db->affected_rows()===false)?false:true;		
		}
	}
	public function deleteRecord($id){
		$this->db->where(['id'=>$id])->delete('network_router_properties');
		return ($this->db->affected_rows()==1)?true:false;
	}
}