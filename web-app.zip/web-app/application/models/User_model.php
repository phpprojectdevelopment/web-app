<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{

	public function __construct(){
		$this->load->database();
		$this->load->library('session');
	}

	public function register(){

		$email = $this->input->post('email');
		$confirmPassword = $this->input->post('confirm_password');
		$password = $this->input->post('password');
		$firstname = $this->input->post('firstname');
		$lastname = $this->input->post('lastname');

		if($firstname==null || $firstname==''){
			exit(json_encode(array('status'=>'failed','message'=>'Firstname required')));
		}

		if($lastname==null || $lastname==''){
			exit(json_encode(array('status'=>'failed','message'=>'Lastname required')));
		}

		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			exit(json_encode(array('status'=>'failed','message'=>'Invalid email')));
		}

		if($confirmPassword!=$password){
			exit(json_encode(array('status'=>'failed','message'=>'Password not matching')));
		}

		$data = array(
			'firstname'=>$firstname,
			'lastname'=>$this->input->post('lastname'),
			'email'=>$email,
			'password'=>$this->strongPassword($this->input->post('password'))
			);

		if($this->emailExists($email)==1){
			exit(json_encode(array('status'=>'failed', 'message'=>'Email already registered')));
		}
		$this->db->insert('users',$data);
		return ($this->db->affected_rows()==1)?true:false;
	}

	public function login(){
		$email = $this->input->post('email');
		
		if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
			exit(json_encode(array('status'=>'failed','message'=>'Invalid email')));
		}

		$userPassword = $this->input->post('password');
		$data = $this->getUserDetails($email);

		if($data!=null){
			$passwordStatus = $this->passwordMatching($data['password'], $userPassword);
			if($passwordStatus==false){
				exit(json_encode(array('status'=>'failed', 'message'=>'Password not matching')));
			}
			$userdata = array('firstname'=>$data['firstname'],'lastname'=>$data['lastname']);
			$this->session->set_userdata('logged_in', $userdata);
			// return $this->session->userdata('logged_in');
			return true;
		}else{
			exit(json_encode(array('status'=>'failed','message'=>'Login credentails not matching')));
		}
	}

	public function getUserDetails($email){
		return $this->db->where(['email'=>$email])
				->select("firstname,lastname,password")
				->get('users')
				->row_array();
	}

	public function emailExists($email){
		return $this->db->where(['email'=>$email])
					->limit(1)
					->get('users')
					->num_rows();
	}
	
	public function passwordMatching($dbPassword, $userPassword){
        $pwd = explode(':',$dbPassword);
        $pwd2Part = $pwd[1];
        $dbSystemPassword = $pwd[0];
        $userCustomPassword = md5($pwd2Part.$userPassword);

        if($dbSystemPassword==$userCustomPassword){
            return true;
        }
        return false;
    }

    public function strongPassword($password){ // For storing or updating purpose
        $salt = $this->getRandomString();    
        if($password!=null && $salt!=null){
            return md5($salt.$password).':'.$salt;
        }
    }   

    public function getRandomString(){
        $range = 32;
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for($i=0;$i<$range;$i++){
            $index = mt_rand(0, strlen($characters)-1);    
            $randomString .= $characters[$index];
        }
        return $randomString;
    }
}