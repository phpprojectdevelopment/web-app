<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");

class Crud_app extends CI_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('crud_model');
	}
	public function getRecords(){
		$page_number = $this->input->get_post('page_number');
		$records = $this->crud_model->getNetworkRouterProperties($page_number);
		if($records==null){
			exit(json_encode(array('status'=>'failed','message'=>'No records found')));
		}
		echo json_encode(array('status'=>'success','message'=>'Records found', 'data'=>$records));
	}
	public function showNetworkRouterList(){
		$this->load->view('crud-app/index');
	}
	public function setData(){

		$id = (int) $this->input->get_post('id');
		$dns_records = $this->input->get_post('dns_records');
		$internet_host_name = $this->input->get_post('internet_host_name');
		$client_ip_address = $this->input->get_post('client_ip_address');
		$mac_address = $this->input->get_post('mac_address');

		if($dns_records==null || $dns_records==''){
			exit(json_encode(array('status'=>'failed','message'=>'DNS records required')));
		}
		if($internet_host_name==null || $internet_host_name==''){
			exit(json_encode(array('status'=>'failed','message'=>'Internet host required')));
		}
		if($client_ip_address==null || $client_ip_address==''){
			exit(json_encode(array('status'=>'failed','message'=>'Client IP address required')));
		}
		if($mac_address==null || $mac_address==''){
			exit(json_encode(array('status'=>'failed','message'=>'MAC address required')));
		}

		$data = array(
				'dns_records'=>$this->filterData($dns_records),
				'internet_host_name'=>$this->filterData($internet_host_name),
				'client_ip_address'=>$this->filterData($client_ip_address),
				'mac_address'=>$this->filterData($mac_address)
				);

		if($id==null){
			$insertStatus = $this->crud_model->newEntry($data);
			if($insertStatus==true){
				echo json_encode(array('status'=>'success','message'=>'New entry created'));
			}
		}else{
			if(!is_numeric($id)){
				exit(json_encode(array('status'=>'failed','message'=>'Invalid ID')));	
			}
			$updateStatus = $this->crud_model->updateData($id,$data);
			if($updateStatus==true){
				echo json_encode(array('status'=>'success','message'=>'Record updated successfully'));
			}
		}
	}

	public function deleteDNSRecords(){
		$id = (int) $this->input->get_post('id');
		if(!is_numeric($id) || $id==null || $id==''){
			exit(json_encode(array('status'=>'failed','message'=>'Invalid ID')));	
		}
		$deleteStatus = $this->crud_model->deleteRecord($id);
		if($deleteStatus==false){
			exit(json_encode(array('status'=>'failed','message'=>'Something went wrong, please try again after sometime')));
		}
		echo json_encode(array('status'=>'success','message'=>'Record deleted successfully'));
	}

	public function filterData($inputData){
		$inputData = trim($inputData);
		$inputData = stripslashes($inputData);
		$inputData = htmlspecialchars($inputData);
		return $inputData;
	}
}