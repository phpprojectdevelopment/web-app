<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");

class Questions extends CI_Controller{
	public function __construct(){
		parent::__construct();
	}

	public function generateUniquId(){
		$unique_id_range = 20;
		for($i=1;$i<=$unique_id_range;$i++){
			echo strtotime(date('ymdhis')).$i."<br>"; // You will get last interger unique
		}
	}

	public function drawGeometricFigures(){
		// Set the vertices of polygon
		$values = array( 
		            150, 50, // Point 1 (x, y) 
		            55, 119, // Point 2 (x, y) 
		            91, 231, // Point 3 (x, y) 
		            209, 231, // Point 4 (x, y) 
		            245, 119  // Point 5 (x, y) 
		            );
		// Create the size of image or blank image 
		$image = imagecreatetruecolor(300, 300); 
		// Set the background color of image 
		$background_color = imagecolorallocate($image,  0, 153, 0); 
		// Fill background with above selected color 
		imagefill($image, 0, 0, $background_color); 
		// Allocate a color for the polygon 
		$col_poly = imagecolorallocate($image, 255, 255, 255); 
		// Draw the polygon 
		imagepolygon($image, $values, 5, $col_poly); 
		// Output the picture to the browser 
		header('Content-type: image/png');   
		imagepng($image);
	}

	public function zipFilesActivity(){
		$this->createNumberOfFiles();
		$this->zipAllFiles();
		$this->downloadAndExtract();		
	}

	public function createNumberOfFiles(){
		$pathForFile = "assets/zip-activity/create-file/";
		$totalFiles = 5;
		for($i=1;$i<=$totalFiles;$i++){
			$content = "number ".$i." content/data.";
			$fp = fopen($pathForFile.'myTextFile'.$i.'.txt',"w");
			fwrite($fp,$content);
			fclose($fp);
		}
	}

	public function zipAllFiles(){
		// Enter the name of directory 
		$pathdir = "assets/zip-activity/create-file/";
		// Enter the name to creating zipped directory 
		$zipcreated = "assets/zip-activity/zip-files/allZipFiles.zip";
		// Create new zip class 
		$zip = new ZipArchive;
		if($zip->open($zipcreated, ZipArchive::CREATE ) === TRUE) {
		    // Store the path into the variable 
		    $dir = opendir($pathdir);
		    while($file = readdir($dir)) { 
		        if(is_file($pathdir.$file)) { 
		            $zip -> addFile($pathdir.$file, $file); 
		        } 
		    } 
		    $zip ->close(); 
		}
	}

	public function downloadAndExtract(){
		$getPath = "assets/zip-activity/zip-files/allZipFiles.zip";
		$putPath = "assets/zip-activity/download-and-extract-file/allZipFiles.zip";
		$f = file_put_contents($putPath, fopen($getPath, 'r'), LOCK_EX);
		if(FALSE === $f)
		    die("Couldn't write to file.");
		$zip = new ZipArchive;
		$res = $zip->open($putPath);
		if ($res === TRUE) {
		  $zip->extractTo("assets/zip-activity/download-and-extract-file/");
		  $zip->close();
		} else {
		  echo 'Something went wrong, your file not extracted';
		}
	}
}	