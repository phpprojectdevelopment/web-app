<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('user_model');
	}
	public function displayForm(){
		// header("Access-Control-Allow-Origin: *");
		$user = $this->session->userdata('logged_in');
		if($user==null){
			$this->loadLoginRegister();
		}
		if($user!=null){
			$this->loadNetworkRouterPropertiesList();
		}
	}
	public function registerUser(){
		$registrationStatus = $this->user_model->register();
		if($registrationStatus==false){
			exit(json_encode(array('status'=>'failed', 'message'=>'Something went wrong, please try again after sometime')));
		}
		echo json_encode(array('status'=>'success', 'message'=>'Registration done, please login'));
	}
	public function checkLogin(){ 
		$loginStatus = $this->user_model->login();
		if($loginStatus==true){
			// $this->loadNetworkRouterPropertiesList();
			echo json_encode(array('status'=>'success', 'message'=>'Login success'));
		}
	}
	public function loadNetworkRouterPropertiesList(){
		// $this->load->model('crud_model');
		$this->load->view('crud-app/index');
		// redirect(base_url().'crud_app/showNetworkRouterList');
	}
	public function loadLoginRegister(){
		$this->load->view('users/register-login');
	}
	public function logout(){
		$this->session->sess_destroy();
		$this->loadLoginRegister();
	}

}